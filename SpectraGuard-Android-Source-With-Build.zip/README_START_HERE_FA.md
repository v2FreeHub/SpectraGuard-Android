# شروع سریع Spectra Guard

این بسته سورس اولیهٔ اندروید و یک workflow برای ساخت APK آزمایشی در GitHub Actions را دارد.

## آپلود با گوشی
1. ZIP را از حالت فشرده خارج کن؛ GitHub گزینهٔ Upload files پوشهٔ ZIP را به‌صورت خودکار باز نمی‌کند.
2. در مخزن `https://github.com/v2FreeHub/SpectraGuard-Android` روی `Add file` و سپس `Upload files` بزن.
3. فایل‌ها و پوشه‌های داخل پروژه را انتخاب و آپلود کن، به‌طوری‌که `README.md` و `settings.gradle.kts` در ریشهٔ مخزن باشند و پوشهٔ `.github/workflows` نیز حفظ شود.
4. Commit changes را بزن.
5. در تب Actions، workflow با نام `Build Spectra Guard APK` را باز کن و در صورت نیاز `Run workflow` را بزن.
6. پس از موفقیت، در صفحهٔ اجرای workflow بخش Artifacts فایل `SpectraGuard-debug-apk` را دانلود کن.

## هشدار مهم
این پروژه در حال حاضر فقط اسکلت رابط اندروید و سرویس VPN آزمایشی است؛ موتور تونل Xray/libXray هنوز یکپارچه نشده. APK ساخته‌شده در این مرحله **اتصال واقعی VLESS/VMess/Trojan فراهم نمی‌کند** و نباید به‌عنوان VPN فعال استفاده یا معرفی شود.
