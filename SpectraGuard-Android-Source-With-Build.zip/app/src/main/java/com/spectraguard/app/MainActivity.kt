package com.spectraguard.app

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONObject
import java.net.URI
import java.util.Base64

/**
 * Branded UI and config import foundation.
 * Real traffic tunnelling requires the Xray/libXray Android core integration described in README.md.
 */
class MainActivity : Activity() {
    private val cyan = Color.rgb(34, 211, 238)
    private lateinit var status: TextView
    private lateinit var configInput: EditText
    private lateinit var configsText: TextView
    private val prefs by lazy { getSharedPreferences("spectra", MODE_PRIVATE) }
    private val configs = mutableListOf<String>()
    private val VPN_REQUEST = 902

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(2, 6, 23)
        window.navigationBarColor = Color.rgb(2, 6, 23)
        configs.addAll(prefs.getStringSet("configs", emptySet())!!.toList())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(2, 6, 23))
        }
        root.addView(TextView(this).apply {
            text = "SPECTRA GUARD\nSECURE YOUR FREEDOM"
            textSize = 24f; setTextColor(cyan); gravity = Gravity.CENTER
        }, lp(-1, -2))
        status = TextView(this).apply {
            text = "وضعیت: قطع شده"
            textSize = 16f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        root.addView(status, lp(-1, 64))
        val connect = Button(this).apply {
            text = "اتصال / قطع اتصال"
            setOnClickListener { requestVpnPermission() }
        }
        root.addView(connect, lp(-1, 56))
        configInput = EditText(this).apply {
            hint = "کانفیگ VLESS / VMess / Trojan یا لینک ساب"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setSingleLine(false); minLines = 2
        }
        root.addView(configInput, lp(-1, 100))
        root.addView(Button(this).apply {
            text = "ذخیره کانفیگ"
            setOnClickListener { addConfig() }
        }, lp(-1, 52))
        root.addView(Button(this).apply {
            text = "حذف همه کانفیگ‌ها"
            setOnClickListener {
                configs.clear(); saveConfigs(); refreshList()
            }
        }, lp(-1, 48))
        configsText = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f }
        val scroll = ScrollView(this).apply { addView(configsText) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshList()
    }

    private fun lp(w: Int, h: Int) = LinearLayout.LayoutParams(w, h).apply { setMargins(0, 6, 0, 6) }

    private fun addConfig() {
        val raw = configInput.text.toString().trim()
        if (raw.isBlank()) { toast("ابتدا کانفیگ را وارد کنید"); return }
        val valid = raw.startsWith("vless://") || raw.startsWith("vmess://") ||
                raw.startsWith("trojan://") || raw.startsWith("https://") || raw.startsWith("http://")
        if (!valid) { toast("فرمت پشتیبانی‌نشده"); return }
        configs.add(raw); saveConfigs(); configInput.setText(""); refreshList()
        toast("کانفیگ ذخیره شد")
    }

    private fun saveConfigs() { prefs.edit().putStringSet("configs", configs.toSet()).apply() }

    private fun refreshList() {
        configsText.text = if (configs.isEmpty()) "هنوز کانفیگی اضافه نشده است." else
            configs.mapIndexed { i, s -> "${i + 1}. ${displayName(s)}\n${s.take(85)}…" }.joinToString("\n\n")
    }

    private fun displayName(raw: String): String = try {
        val hash = raw.substringAfter("#", "")
        if (hash.isNotBlank()) java.net.URLDecoder.decode(hash, "UTF-8")
        else when {
            raw.startsWith("vless://") -> "VLESS"
            raw.startsWith("vmess://") -> "VMess"
            raw.startsWith("trojan://") -> "Trojan"
            else -> "Subscription"
        }
    } catch (_: Exception) { "Server" }

    private fun requestVpnPermission() {
        if (configs.isEmpty()) { toast("ابتدا یک کانفیگ اضافه کنید"); return }
        // This permission only authorizes a VPN service; it does not implement a tunnel by itself.
        val intent = VpnService.prepare(this)
        if (intent != null) startActivityForResult(intent, VPN_REQUEST)
        else startActivity(Intent(this, SpectraVpnService::class.java).setAction(SpectraVpnService.ACTION_START))
    }

    @Deprecated("Legacy callback kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST && resultCode == RESULT_OK) {
            status.text = "مجوز VPN صادر شد؛ موتور Xray هنوز باید متصل شود."
            toast("مجوز سیستم صادر شد؛ اتصال واقعی تا افزودن موتور Xray فعال نیست.")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
