package com.spectraguard.app

import android.net.VpnService
import android.content.Intent
import android.os.ParcelFileDescriptor
import android.util.Log

/**
 * Android VPN service shell. It intentionally does NOT claim to tunnel traffic.
 * Wire this service to a maintained Xray/libXray core and its TUN file-descriptor API.
 */
class SpectraVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                Log.w(TAG, "VPN permission granted, but Xray core adapter is not integrated.")
                stopSelf()
            }
            ACTION_STOP -> stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.spectraguard.START"
        const val ACTION_STOP = "com.spectraguard.STOP"
        private const val TAG = "SpectraGuard"
    }
}
